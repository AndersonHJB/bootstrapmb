"use strict";
/*window.odometerOptions = {
  auto: true, // Don't automatically initialize everything with class 'odometer'
  selector: '.number.animated_element', // Change the selector used to automatically find things to be animated
  format: '( ddd).dd', // Change how digit groups are formatted, and how many digits are shown after the decimal point
  duration: 1500, // Change how long the javascript expects the CSS animation to take
  theme: 'default', // Specify the theme (if you have more than one theme css file on the page)
  animation: 'count' // Count is a simpler animation method which just increments the value,
                     // use it when you're looking for something more subtle.
};*/
if(!Date.prototype.toISOString) 
{
    Date.prototype.toISOString = function() 
	{
        function pad(n) {return n < 10 ? '0' + n : n}
        return this.getUTCFullYear() + '-'
            + pad(this.getUTCMonth() + 1) + '-'
                + pad(this.getUTCDate()) + 'T'
                    + pad(this.getUTCHours()) + ':'
                        + pad(this.getUTCMinutes()) + ':'
                            + pad(this.getUTCSeconds()) + 'Z';
    };
}
function getRandom(min,max)
{
	return((Math.floor(Math.random()*(max-min)))+min);
}
var pr_id = 0;
function prUniqueId()
{
	return pr_id++;
}
function getCookie(c_name)
{
	var i,x,y,ARRcookies=document.cookie.split(";");
	for (i=0;i<ARRcookies.length;i++)
	{
		x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
		y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
		x=x.replace(/^\s+|\s+$/g,"");
		if (x==c_name)
		{
			return unescape(y);
		}
	}
}
function setCookie(c_name,value,exdays)
{
	var exdate=new Date();
	exdate.setDate(exdate.getDate() + exdays);
	var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
	document.cookie=c_name + "=" + c_value + ";domain=;path=/";
}
function onBeforeScroll(obj)
{	
	var currentTimeago = jQuery(this).parent().parent().next().children(".current");
	/*currentTimeago.fadeOut(500, function(){
		$(this).removeClass("current");
		if(obj.scroll.direction=="next")
		{
			if(currentTimeago.next().length)
				currentTimeago.next().addClass("current");
			else
				currentTimeago.parent().children().first().addClass("current");
		}
		else
		{
			if(currentTimeago.prev().length)
				currentTimeago.prev().addClass("current");
			else
				currentTimeago.parent().children().last().addClass("current");
		}
		var object = currentTimeago.next();
		var text = object.text();
		object.text("");

		var length = text.length;
		var timeOut;
		var character = 0;

		
		(function typeWriter() { 
			timeOut = setTimeout(function() {
				character++;
				var type = text.substring(0, character);
				object.text(type);
				typeWriter();
				
				if (character == length) {
					clearTimeout(timeOut);
				}
				
			}, 50);
		}());
	});*/
	currentTimeago.fadeOut(obj.scroll.duration, function(){
		jQuery(this).removeClass("current");
		if(obj.scroll.direction=="next")
		{
			if(jQuery(this).next().length)
				jQuery(this).next().fadeIn(obj.scroll.duration).addClass("current");
			else
				jQuery(this).parent().children().first().fadeIn(obj.scroll.duration).addClass("current");
		}
		else
		{
			if(jQuery(this).prev().length)
				jQuery(this).prev().fadeIn(obj.scroll.duration).addClass("current");
			else
				jQuery(this).parent().children().last().fadeIn(obj.scroll.duration).addClass("current");
		}
	});
}

function pushState(event)
{
	event.preventDefault();
	var History = window.History;
	var url = jQuery(this).attr("href");
	if(typeof(url)!="undefined")
	{
		var hashSplit = url.split("#");
		if(event.data.pr_option=="theme_blog_pagination" && event.data.action.length)
		{
			if(jQuery(this).parent().hasClass("selected"))
				return false;
			var container = jQuery(this).parent().parent().parent().prev();
			if(typeof(container.attr("id"))=="undefined")
			{
				var expando = prUniqueId();//container["context"][jQuery.expando];
				container.attr("id", event.data.action + expando);
				container.data("expando", expando);
			}
			jQuery(this).parent().parent().parent().attr("id", "pagination" + container.data("expando"));
			event.data.container_id = container.attr("id");
			jQuery(this).parent().parent().children(".selected").removeClass("selected");
			jQuery(this).parent().addClass("selected");
			event.data.paged = jQuery(event.target).data("page");
		}
		
		if(hashSplit.length==2)
		{
			event.data.hash = hashSplit[1];
			url = url.replace("#" + hashSplit[1], "");
		}
		var title = (jQuery(document).find("title").length ? jQuery(document).find("title").text() : "");
		if(history.pushState)
			History.pushState(event.data, title, url);
		else
			History.pushState(event.data, title, url);
	}
};

var menu_position = null;
jQuery(document).ready(function($){
	var pageTitle = document.title;
	//odometer
	$('.number.animated_element').each(function(){
		var self = $(this)[0];
		var od = new Odometer({
			el: self,
			format: '( ddd).dd',
			duration: 1500,
			theme: 'default',
			animation: 'count'
		});
	});
	//mobile menu
	$(".mobile-menu-switch").on("click", function(event){
		event.preventDefault();
		if(!$(".mobile-menu").is(":visible"))
			$(".mobile-menu-divider").css("display", "block");
		$(".mobile_menu_container .ubermenu").slideToggle(500, function(){
			if(!$(".mobile_menu_container .ubermenu").is(":visible"))
				$(".mobile-menu-divider").css("display", "none");
		});
	});
	$(".collapsible-mobile-submenus .template-arrow-menu").on("click", function(event){
		event.preventDefault();
		$(this).next().slideToggle(300);
	});
	
	//slider
	$(".slider").each(function(index){
		var id = "slider";
		var autoplay = 0;
		var pause_on_hover = 0;
		var interval = 5000;
		var effect = "scroll";
		var easing = "easeInOutQuint";
		var duration = 750;
		var elementClasses = $(this).attr('class').split(' ');
		for(var i=0; i<elementClasses.length; i++)
		{
			if(elementClasses[i].indexOf('id-')!=-1)
				id = elementClasses[i].replace('id-', '');
			if(elementClasses[i].indexOf('autoplay-')!=-1)
				autoplay = elementClasses[i].replace('autoplay-', '');
			if(elementClasses[i].indexOf('pause_on_hover-')!=-1)
				pause_on_hover = elementClasses[i].replace('pause_on_hover-', '');
			if(elementClasses[i].indexOf('interval-')!=-1)
				interval = elementClasses[i].replace('interval-', '');
		}
		var carouselOptions = {
			responsive: false,
			width: "100%",
			items: {
				start: (config.is_rtl ? -2 : -1),
				visible: 3,
				minimum: 3
			},
			scroll: {
				items: 1,
				easing: easing,
				duration: parseInt(duration),
				fx: effect
			},
			auto: {
				play: (parseInt(autoplay) ? true : false),
				timeoutDuration: parseInt(interval),
				pauseDuration: parseInt(interval),
				pauseOnHover: (parseInt(pause_on_hover) ? true : false)
			}
		};
		$(this).carouFredSel(carouselOptions,
		{
			transition: true/*,
			wrapper: {
				classname: "caroufredsel_wrapper caroufredsel_wrapper_slider"
			}*/
		});
		if($(this).children().length>1) 
		{
			$(this).sliderControl({
				appendTo: $(".slider_content_box"),
				listContainer: $("#" + id + ".slider_posts_list_container"),
				listItems: ($(".theme_page .vc_row:not('.full_width')").width()>462 ? 4 : 2)
			});
		}
	});
	
	/*$(".slider").carouFredSel({
		responsive: false,
		//align: "left",
		width: "100%",
		items: {
			start: -1,
			visible: 3,
			minimum: 3
		},
		scroll: {
			items: 1,
			easing: "easeInOutQuint",
			duration: 750,
			fx: "cover"
		},
		/*prev: {
			onAfter: onAfterSlide,
			onBefore: onBeforeSlide,
			easing: "easeInOutQuint",
			duration: 750
		},
		next: {
			onAfter: onAfterSlide,
			onBefore: onBeforeSlide,
			easing: "easeInOutQuint",
			duration: 750
		},*/
		/*auto: {
			play: false,
			timeoutDuration: 500,
			duration: 5000/*,
			onAfter: onAfterSlide,
			onBefore: onBeforeSlide,
			easing: "easeInOutQuint",
			duration: 750*/
		/*}
	},
	{
		transition: true,
		wrapper: {
			classname: "caroufredsel_wrapper caroufredsel_wrapper_slider"
		}
	});	
	$(".slider").sliderControl({
		appendTo: $(".slider_content_box"),
		listContainer: $(".slider_posts_list_container"),
		listItems: ($(".page").width()>462 ? 4 : 2)
	});*/
	
	//small slider
	$(".small_slider").each(function(index){
		$(this).addClass("pr_preloader_ss_" + index);
		//$(".pr_preloader_ss_" + index + " img:first").attr('src',$(".pr_preloader_ss_" + index + " img:first").attr('src'));
		//$(".pr_preloader_ss_" + index + " img:first").before("<span class='pr_preloader'></span>");
		$(".pr_preloader_ss_" + index).before("<span class='pr_preloader'></span>");
		$(".pr_preloader_ss_" + index).imagesLoaded(function(){
			$(".pr_preloader_ss_" + index).prev(".pr_preloader").remove();
			$(".pr_preloader_ss_" + index).fadeTo("slow", 1, function(){
				$(this).css("opacity", "");
			});
			
			/*$(this).prev(".pr_preloader").remove();
			$(this).fadeTo("slow", 1, function(){
				$(this).css("opacity", "");
			});*/
			
			var id = "small_slider";
			var autoplay = 0;
			var pause_on_hover = 0;
			var interval = 5000;
			var elementClasses = $(".pr_preloader_ss_" + index).attr('class').split(' ');
			for(var i=0; i<elementClasses.length; i++)
			{
				if(elementClasses[i].indexOf('id-')!=-1)
					id = elementClasses[i].replace('id-', '');
				if(elementClasses[i].indexOf('autoplay-')!=-1)
					autoplay = elementClasses[i].replace('autoplay-', '');
				if(elementClasses[i].indexOf('pause_on_hover-')!=-1)
					pause_on_hover = elementClasses[i].replace('pause_on_hover-', '');
				if(elementClasses[i].indexOf('interval-')!=-1)
					interval = elementClasses[i].replace('interval-', '');
			}
			$(".pr_preloader_ss_" + index).carouFredSel({
				items: {
					visible: 1,
					minimum: 1,
					start: (config.is_rtl ? -1 : 0)
				},
				scroll: {
					items: 1,
					easing: "easeInOutQuint",
					duration: 750
				},
				auto: {
					play: (parseInt(autoplay) ? true : false),
					timeoutDuration: parseInt(interval),
					pauseDuration: parseInt(interval),
					pauseOnHover: (parseInt(pause_on_hover) ? true : false)
				}/*,
				swipe: {
					items: 1,
					easing: "easeInOutQuint",
					onTouch: true,
					onMouse: false,
					options: {
						allowPageScroll: "vertical",
						excludedElements:"button, input, select, textarea, .noSwipe"
					},
					duration: 750
				}*/
			}/*,
			{
				wrapper: {
					classname: "caroufredsel_wrapper caroufredsel_wrapper_small_slider"
				}
			}*/);
			$(".pr_preloader_ss_" + index + " li img").css("display", "block");
			$(".pr_preloader_ss_" + index + " li .icon").css("display", "block");
			$(".pr_preloader_ss_" + index).sliderControl({
				type: "small",
				appendTo: $(".slider_content_box"),
				listContainer: $("#" + id + ".slider_posts_list_container.small"),
				listItems: ($(".theme_page .vc_row:not('.full_width')").width()>462 ? 3 : 2)
			});
		});
	});
	
	//blog grid
	$(".blog_grid .slider_content_box").on("click", function(event){
		if(event.target.nodeName.toUpperCase()!="A")
			window.location.href = $(this).find("h2 a, h5 a").attr("href");
	});
			
	var controlBySlideLeft = function(param){
		var self = $(this);
		var index = (typeof(param.data)!="undefined" ? param.data.index : param);
		$("#" + self.parent().attr("id").replace("control-by-", "")).trigger("isScrolling", function(isScrolling){
			if(!isScrolling)
			{
				var controlFor = $(".control-for-" + self.parent().attr("id").replace("control-by-", ""));
				var currentIndex = controlFor.children().index(controlFor.children(".current"));
				if(currentIndex==0)
				{
					controlFor.trigger("prevPage");
					if(controlFor.children(".current").prev().length)
						controlFor.children(".current").removeClass("current").prev().addClass("current");
					else
					{
						controlFor.children(".current").removeClass("current");
						controlFor.children(":last").addClass("current");
					}
				}
				else if(currentIndex>controlFor.triggerHandler("currentVisible").length+1)
				{	
					var slideToIndex = parseInt($(this).children(":first").attr("id").replace("horizontal_slide_" + index + "_", ""));
					if(slideToIndex==0)
						slideToIndex = controlFor.children().length-1;
					else
						slideToIndex--;
					//controlFor.trigger("slideTo", slideToIndex);
					controlFor.trigger("slideTo", [slideToIndex, {
						onAfter: function(){
							controlFor.children(".current").removeClass("current");
							controlFor.children(":first").addClass("current");
						}
					}]);
					
				}
				else
					controlFor.children(".current").removeClass("current").prev().addClass("current");
			}
		});
	};
	var controlBySlideRight = function(param){
		var self = $(this);
		var index = (typeof(param.data)!="undefined" ? param.data.index : param);
		$("#" + self.parent().attr("id").replace("control-by-", "")).trigger("isScrolling", function(isScrolling){
			if(!isScrolling)
			{
				var controlFor = $(".control-for-" + self.parent().attr("id").replace("control-by-", ""));
				var currentIndex = controlFor.children().index(controlFor.children(".current"));
				if(currentIndex==controlFor.triggerHandler("currentVisible").length)
				{
					controlFor.trigger("nextPage");
					controlFor.children(".current").removeClass("current").next().addClass("current");
				}
				else if(currentIndex>controlFor.triggerHandler("currentVisible").length)
				{
					var slideToIndex = parseInt($(this).children(":first").attr("id").replace("horizontal_slide_" + index + "_", ""));
					if(slideToIndex==controlFor.children().length-1)
						slideToIndex = 0;
					else
						slideToIndex++;
					//controlFor.trigger("slideTo", [slideToIndex, "next"]);
					controlFor.trigger("slideTo", slideToIndex);
					controlFor.children(".current").removeClass("current");
					controlFor.children(":first").addClass("current");
				}
				else
				{
					if(controlFor.children(".current").next().length)
						controlFor.children(".current").removeClass("current").next().addClass("current");
					else
					{
						controlFor.children(".current").removeClass("current");
						controlFor.children(":first").addClass("current");
					}
				}
			}
		});
	};
	//horizontal carousel
	var horizontalCarousel = function()
	{
		$(".horizontal_carousel").each(function(index){
			$(this).addClass("pr_preloader_" + index);
			//$(".pr_preloader_" + index + " img:first").attr('src',$(".pr_preloader_" + index + " img:first").attr('src'));
			$(".pr_preloader_" + index).before("<span class='pr_preloader'></span>");
			$(".pr_preloader_" + index).imagesLoaded(function(instance){
				//console.log($(instance.elements[0]));
				$(".pr_preloader_" + index).prev(".pr_preloader").remove();
				$(".pr_preloader_" + index).fadeTo("slow", 1, function(){
					$(this).css("opacity", "");
				});
				
				/*$(this).prev(".pr_preloader").remove();
				$(this).fadeTo("slow", 1, function(){
					$(this).css("opacity", "");
				});*/
				//caroufred
				var visible = 3;
				var autoplay = 0;
				var pause_on_hover = 0;
				var scroll = 1;
				var effect = "scroll";
				var easing = "easeInOutQuint";
				var duration = 750;
				var navigation = 1;
				var control_for = "";
				var elementClasses = $(".pr_preloader_" + index).attr('class').split(' ');
				for(var i=0; i<elementClasses.length; i++)
				{
					if(elementClasses[i].indexOf('visible-')!=-1)
						visible = elementClasses[i].replace('visible-', '');
					if(elementClasses[i].indexOf('autoplay-')!=-1)
						autoplay = elementClasses[i].replace('autoplay-', '');
					if(elementClasses[i].indexOf('pause_on_hover-')!=-1)
						pause_on_hover = elementClasses[i].replace('pause_on_hover-', '');
					if(elementClasses[i].indexOf('scroll-')!=-1)
						scroll = elementClasses[i].replace('scroll-', '');
					if(elementClasses[i].indexOf('effect-')!=-1)
						effect = elementClasses[i].replace('effect-', '');
					if(elementClasses[i].indexOf('easing-')!=-1)
						easing = elementClasses[i].replace('easing-', '');
					if(elementClasses[i].indexOf('duration-')!=-1)
						duration = elementClasses[i].replace('duration-', '');
					if(elementClasses[i].indexOf('navigation-')!=-1)
						navigation = elementClasses[i].replace('navigation-', '');
					/*if(elementClasses[i].indexOf('threshold-')!=-1)
						var threshold = elementClasses[i].replace('threshold-', '');*/
					if(elementClasses[i].indexOf('control-for-')!=-1)
						control_for = elementClasses[i].replace('control-for-', '');
				}
				
				/*var length = $(this).children().length;
				if(length<visible)
					visible = length;*/
				
				var length = $(".pr_preloader_" + index).children().length;
				if($(".theme_page .vc_row:not('.full_width')").width()<=462 && parseInt(visible, 10)>2)
				{
					visible = 2;
					if($(".theme_page .vc_row:not('.full_width')").width()<=300)
						visible = 1;
				}
				if(length<parseInt(visible, 10))
					visible = length;
				if(control_for!=""/* && !config.is_rtl*/)
					visible = 0;
				var carouselOptions = {
					direction: (config.is_rtl==1 ? "right" : "left"),
					items: {
						start: (config.is_rtl==1 && control_for=="" && typeof($(".pr_preloader_" + index).attr("id"))=="undefined" ? length-($(".theme_page .vc_row:not('.full_width')").width()>750 ? visible : ($(".theme_page .vc_row:not('.full_width')").width()>462 ? visible-1 : visible)) : 0),
						visible: parseInt(visible, 10)
					},
					scroll: {
						items: parseInt(scroll),
						fx: effect,
						easing: easing,
						duration: parseInt(duration),
						pauseOnHover: (parseInt(pause_on_hover) ? true : false),
						onAfter: function(){
							var popup = false;
							if(typeof($(this).attr("id"))!="undefined")
							{
								var split = $(this).attr("id").split("-");
								if(split[split.length-1]=="popup")
									popup = true;
							}
							if(popup)
								var scroll = $(".gallery_popup").scrollTop();
							$(this).trigger('configuration', [{scroll :{
								easing: "easeInOutQuint",
								duration: 750
							}}, true]);
							if($(".control-for-" + $(this).attr("id")).length)
							{
								$(".control-for-" + $(this).attr("id")).trigger("configuration", {scroll: {
									easing: "easeInOutQuint",
									duration: 750
								}});
							}
							if(popup)
								$(".gallery_popup").scrollTop(scroll);
						}
					},
					auto: {
						items: parseInt(scroll),
						play: (parseInt(autoplay) ? true : false),
						fx: effect,
						easing: easing,
						duration: parseInt(duration),
						pauseOnHover: (parseInt(pause_on_hover) ? true : false),
						onAfter: null
					}/*,
					swipe: {
						items: parseInt(scroll),
						easing: easing,
						duration: parseInt(duration),
						onTouch: true,
						onMouse: false,
						options: {
							allowPageScroll: "vertical",
							excludedElements:"button, input, select, textarea, .noSwipe"
						}
					}*/
				};
				$(".pr_preloader_" + index).carouFredSel(carouselOptions,{
					wrapper: {
						classname: "caroufredsel_wrapper caroufredsel_wrapper_hortizontal_carousel"
					}
				});
				
				if(parseInt(navigation))
				{
					$(".pr_preloader_" + index).parent().before("<a class='slider_control left slider_control_" + index + "' href='#' title='prev'></a>");
					$(".pr_preloader_" + index).parent().after("<a class='slider_control right slider_control_" + index + "' href='#' title='next'></a>");
					$(".pr_preloader_" + index).parent().parent().hover(function(){
						$(".horizontal_carousel_container .left.slider_control_" + index).removeClass("slideRightBack").addClass("slideRight");
						$(".horizontal_carousel_container .right.slider_control_" + index).removeClass("slideLeftBack").addClass("slideLeft");
						$(".horizontal_carousel_container .pr_preloader_" + index + " .fullscreen").removeClass("slideRightBack").addClass("slideRight");
					},
					function(){
						$(".horizontal_carousel_container .left.slider_control_" + index).removeClass("slideRight").addClass("slideRightBack");
						$(".horizontal_carousel_container .right.slider_control_" + index).removeClass("slideLeft").addClass("slideLeftBack");
						$(".horizontal_carousel_container .pr_preloader_" + index + " .fullscreen").removeClass("slideRight").addClass("slideRightBack");
					});
				}
				$(".pr_preloader_" + index).trigger('configuration', ['prev', {button: $(".horizontal_carousel_container .left.slider_control_" + index)}, false]);
				$(".pr_preloader_" + index).trigger('configuration', ['next', {button: $(".horizontal_carousel_container .right.slider_control_" + index)}, false]);
				$(".pr_preloader_" + index + " li img").css("display", "block");
				$(".pr_preloader_" + index + " li .icon").css("display", "block");
				$(".pr_preloader_" + index).trigger('configuration', ['debug', false, true]); //for width
				
				var self = $(".pr_preloader_" + index);
				var base = "x";
				var scrollOptions = {
					scroll: {
						easing: "linear",
						duration: 200
					}
				};
				self.swipe({
					fallbackToMouseEvents: false,
					allowPageScroll: "vertical",
					excludedElements:"button, input, select, textarea, .noSwipe",
					swipeStatus: function(event, phase, direction, distance, fingerCount, fingerData ) {
						//if(!self.is(":animated") && (!$(".control-for-" + self.attr("id")).length || ($(".control-for-" + self.attr("id")).length && !$(".control-for-" + self.attr("id")).is(":animated"))))
						if(!self.is(":animated"))
						{
							self.trigger("isScrolling", function(isScrolling){
								if(!isScrolling)
								{
									if (phase == "move" && (direction == "left" || direction == "right")) 
									{
										if(base=="x")
										{
											if($(".gallery_popup").is(":visible"))
												var scroll = $(".gallery_popup").scrollTop();
											self.trigger("configuration", scrollOptions);
											if($(".control-for-" + self.attr("id")).length)
												$(".control-for-" + self.attr("id")).trigger("configuration", scrollOptions);
											if($(".gallery_popup").is(":visible"))
												$(".gallery_popup").scrollTop(scroll);
											self.trigger("pause");
										}
										if (direction == "left") 
										{
											if(base=="x")
												base = 0;
											self.css("left", parseInt(base)-distance + "px");
										} 
										else if (direction == "right") 
										{	
											if(base=="x" || base==0)
											{
												self.children().last().prependTo(self);
												base = -self.children().first().width()-parseInt(self.children().first().css("margin-right"));
											}
											self.css("left", base+distance + "px");
										}

									} 
									else if (phase == "cancel") 
									{
										if(distance!=0)
										{
											self.trigger("play");
											self.animate({
												"left": base + "px"
											}, 750, "easeInOutQuint", function(){
												if($(".gallery_popup").is(":visible"))
													var scroll = $(".gallery_popup").scrollTop();
												if(base==-self.children().first().width()-parseInt(self.children().first().css("margin-right")))
												{
													self.children().first().appendTo(self);
													self.css("left", "0px");
													base = "x";
												}
												self.trigger("configuration", {scroll: {
													easing: "easeInOutQuint",
													duration: 750
												}});
												if($(".control-for-" + self.attr("id")).length)
													$(".control-for-" + self.attr("id")).trigger("configuration", {scroll: {
														easing: "easeInOutQuint",
														duration: 750
													}});
												if($(".gallery_popup").is(":visible"))
													$(".gallery_popup").scrollTop(scroll);
											});
										}
									} 
									else if (phase == "end") 
									{
										self.trigger("play");
										if (direction == "right") 
										{
											if(typeof(self.parent().parent().attr("id"))!="undefined" && self.parent().parent().attr("id").indexOf('control-by')==0)
											{
												if($(".horizontal_carousel_container .left.slider_control_" + index).length)
													controlBySlideLeft.call($(".horizontal_carousel_container .left.slider_control_" + index), index);
												else
													controlBySlideLeft.call($(".pr_preloader_" + index).parent(), index);
											}
											self.animate({
												"left": 0 + "px"
											}, 200, "linear", function(){
												if($(".gallery_popup").is(":visible"))
													var scroll = $(".gallery_popup").scrollTop();
												self.trigger("configuration", {scroll: {
													easing: "easeInOutQuint",
													duration: 750
												}});
												if($(".control-for-" + self.attr("id")).length)
													$(".control-for-" + self.attr("id")).trigger("configuration", {scroll: {
														easing: "easeInOutQuint",
														duration: 750
													}});
												if($(".gallery_popup").is(":visible"))
													$(".gallery_popup").scrollTop(scroll);
												base = "x";
											});
											
										} 
										else if (direction == "left") 
										{
											if(base==-self.children().first().width()-parseInt(self.children().first().css("margin-right")))
											{
												self.children().first().appendTo(self);
												self.css("left", (parseInt(self.css("left"))-base)+"px");
											}
											if($(".horizontal_carousel_container .right.slider_control_" + index).length)
												$(".horizontal_carousel_container .right.slider_control_" + index).trigger("click");
											else
												$(".horizontal_carousel_container .slider_control .right_" + index).trigger("click");
											base = "x";
										}
									}
								}
							});
						}
					}
				});
				$(window).trigger("resize");
				$(".pr_preloader_" + index).trigger('configuration', ['debug', false, true]); //for height
				if(control_for!="")
				{
					$(".pr_preloader_" + index).children().each(function(child_index){
						if(child_index==0)
							$(this).addClass("current");
						$(this).attr("id", "horizontal_slide_" + index + "_" + child_index);
					});
					$(".pr_preloader_" + index).children().on("click", function(event){
						event.preventDefault();
						var self = $(this);
						$("#" + control_for).trigger("isScrolling", function(isScrolling){
							if(!isScrolling)
							{
								var slideIndex = self.attr("id").replace("horizontal_slide_" + index + "_", "");
								self.parent().children().removeClass("current");
								self.addClass("current");
								var controlForIndex = parseInt($("#" + control_for).children(":first").attr("id").split("_")[2]);
								//$("#" + control_for).trigger("slideTo", parseInt(slideIndex));
								$("#" + control_for).trigger("slideTo", $("#horizontal_slide_" + controlForIndex + "_" + slideIndex));
							}
						});
					});
				}
				$("[id^='control-by-'] .pr_preloader_" + index).children().each(function(child_index){
					$(this).attr("id", "horizontal_slide_" + index + "_" + child_index);
				});
				$("[id^='control-by-'] .left.slider_control_" + index).on("click", {index: index}, controlBySlideLeft);
				$("[id^='control-by-'] .right.slider_control_" + index).on("click", {index: index}, controlBySlideRight);
			});
		});
	};
	horizontalCarousel();
	
	//vertical carousel
	var verticalCarousel = function()
	{
		$(".vertical_carousel").each(function(index){
			$(this).addClass("pr_preloader_vl_" + index);
			//$(".pr_preloader_vl_" + index + " img:first").attr('src',$(".pr_preloader_vl_" + index + " img:first").attr('src'));
			$(".pr_preloader_vl_" + index).imagesLoaded(function(){
				//$(this).prev(".pr_preloader").remove();
				//$(this).fadeTo("slow", 1, function(){
				//	$(this).css("opacity", "");
				//});
				
				//caroufred
				var visible = 3;
				var autoplay = 0;
				var pause_on_hover = 0;
				var scroll = 1;
				var effect = "scroll";
				var easing = "easeInOutQuint";
				var duration = 750;
				var navigation = 1;
				var elementClasses = $(".pr_preloader_vl_" + index).attr('class').split(' ');
				for(var i=0; i<elementClasses.length; i++)
				{
					if(elementClasses[i].indexOf('visible-')!=-1)
						visible = elementClasses[i].replace('visible-', '');
					if(elementClasses[i].indexOf('autoplay-')!=-1)
						autoplay = elementClasses[i].replace('autoplay-', '');
					if(elementClasses[i].indexOf('pause_on_hover-')!=-1)
						pause_on_hover = elementClasses[i].replace('pause_on_hover-', '');
					if(elementClasses[i].indexOf('scroll-')!=-1)
						scroll = elementClasses[i].replace('scroll-', '');
					if(elementClasses[i].indexOf('effect-')!=-1)
						effect = elementClasses[i].replace('effect-', '');
					if(elementClasses[i].indexOf('easing-')!=-1)
						easing = elementClasses[i].replace('easing-', '');
					if(elementClasses[i].indexOf('duration-')!=-1)
						duration = elementClasses[i].replace('duration-', '');
					if(elementClasses[i].indexOf('navigation-')!=-1)
						navigation = elementClasses[i].replace('navigation-', '');
					/*if(elementClasses[i].indexOf('threshold-')!=-1)
						var threshold = elementClasses[i].replace('threshold-', '');*/
				}
				var length = $(".pr_preloader_vl_" + index).children().length;
				if(length<visible)
					visible = length;
				var carouselOptions = {
					direction: "up",
					items: {
						visible: parseInt(visible)
					},
					scroll: {
						items: parseInt(scroll),
						fx: effect,
						easing: easing,
						duration: parseInt(duration),
						pauseOnHover: (parseInt(pause_on_hover) ? true : false)
					},
					auto: {
						items: parseInt(scroll),
						play: (parseInt(autoplay) ? true : false),
						fx: effect,
						easing: easing,
						duration: parseInt(duration),
						pauseOnHover: (parseInt(pause_on_hover) ? true : false)
					}
				};
				$(".pr_preloader_vl_" + index).carouFredSel(carouselOptions,{
					wrapper: {
						classname: "caroufredsel_wrapper caroufredsel_wrapper_vertical_carousel"
					}
				});
				if(navigation)
				{
					$(".pr_preloader_vl_" + index).parent().before("<a class='slider_control up slider_control_" + index + "' href='#' title='prev'></a>");
					$(".pr_preloader_vl_" + index).parent().after("<a class='slider_control down slider_control_" + index + "' href='#' title='next'></a>");
					$(".pr_preloader_vl_" + index).parent().parent().hover(function(){
						$(".vertical_carousel_container .up.slider_control_" + index).removeClass("slideDownBack").addClass("slideDown");
						$(".vertical_carousel_container .down.slider_control_" + index).removeClass("slideUpBack").addClass("slideUp");
					},
					function(){
						$(".vertical_carousel_container .up.slider_control_" + index).removeClass("slideDown").addClass("slideDownBack");
						$(".vertical_carousel_container .down.slider_control_" + index).removeClass("slideUp").addClass("slideUpBack");
					});
				}
				$(".pr_preloader_vl_" + index).trigger('configuration', ['prev', {button: $(".vertical_carousel_container .up.slider_control_" + index)}, false]);
				$(".pr_preloader_vl_" + index).trigger('configuration', ['next', {button: $(".vertical_carousel_container .down.slider_control_" + index)}, false]);
				$(".pr_preloader_vl_" + index + " li img").css("display", "block");
				$(".pr_preloader_vl_" + index + " li .icon").css("display", "block");
				$(".pr_preloader_vl_" + index).trigger('configuration', ['debug', false, true]); //for width
				$(window).trigger("resize");
				$(".pr_preloader_vl_" + index).trigger('configuration', ['debug', false, true]); //for height
			});
		});
	};
	verticalCarousel();
	
	$(".tabs:not('.small') .tabs_navigation").each(function(){
		var count = $(this).children().length;
		$(this).children().width(100/count + '%').append("<span></span>");
	});
	
	var blogRating = function()
	{
		$(".blog.rating").each(function(){
			var topValue = 0, currentValue = 0;
			$(this).children(".post").each(function(index){
				var self = $(this);
				if(self.find("[data-value]").length)
				{
					currentValue = parseInt(self.find("[data-value]").data("value").toString().replace(" ",""));
					if(index==0)
						topValue = currentValue;
					self.append("<div class='value_bar_container' style='width: " + ((currentValue/topValue*100)<5 ? 5 : (currentValue/topValue*100)) + "%; height: " + (self.outerHeight()-self.find("img").height()) + "px;'><div class='value_bar animated_element duration-2000 animation-width'></div></div>");
				}
			});
		});
	}
	blogRating();
	
	var authorsRating = function()
	{
		$(".authors.rating").each(function(){
			var topValue = 0, currentValue = 0;
			$(this).children(".single-author").each(function(index){
				var self = $(this);
				var number = self.find("[data-value]");
				if(number.length)
				{
					currentValue = parseInt(number.data("value").toString().replace(" ",""))
					if(index==0)
						topValue = currentValue;
					number.after("<div class='value_bar_container' style='height: " + ((currentValue/topValue*100)<5 ? 5 : (currentValue/topValue*100)) + "px;'><div class='value_bar animated_element duration-2000 animation-height'></div></div>");
				}
			});
		});
	}
	authorsRating();
	
	var authorsListRating = function()
	{
		$(".authors_list.rating").each(function(){
			var topValue = 0, currentValue = 0;
			$(this).children(".single-author").each(function(index){
				var self = $(this);
				var number = self.find("[data-value]").first();
				if(number.length)
				{
					currentValue = parseInt(number.data("value").toString().replace(" ",""))
					if(index==0)
						topValue = currentValue;
					self.find(".details").append("<div class='value_bar_container' style='width: " + ((currentValue/topValue*100)<5 ? 5 : (currentValue/topValue*100)) + "%; height: " + (self.find(".details").outerHeight()) + "px;'><div class='value_bar animated_element duration-2000 animation-width'></div></div>");
				}
			});
		});
	}
	authorsListRating();
	
	/*var reviewRating = function()
	{
		$(".value_container .value_bar").each(function(){
			if($(this).children("[data-value]").first().length)
			{
				var value = parseFloat($(this).children("[data-value]").first().data("value").toString());
				$(this).parent().css("width", (parseInt(value*10)<13 ? 13 : parseInt(value*10)) + "%");
			}
		});
		$(".review_summary").each(function(){
			if($(this).children("[data-value]").first().length)
			{
				var value = parseFloat($(this).children("[data-value]").first().data("value").toString());
				$(this).append("<div class='value_bar_container' style='width: " + (parseInt(value*10)<5 ? 5 : parseInt(value*10)) + "%; height: " + $(this).outerHeight() + "px;'><div class='value_bar animated_element duration-2000 animation-width'></div></div>");
			}
		});
	}
	reviewRating();*/
	$(".review_summary .value_bar_container").each(function(){
		$(this).height($(this).parent().outerHeight());
	});
	
	
	//vertical carousel
	$(".latest_news_scrolling_list").each(function(){
		var self = $(this);
		var length = self.children().length;
		self.carouFredSel({
			direction: (config.is_rtl==1 ? "right" : "left"),
			width: "variable",
			items: {
				start: (config.is_rtl==1 ? length-1 : 0),
				visible: 1,
				minimum: 1
			},
			prev: {button: self.parent().parent().find('.left')},
			next: {button: self.parent().parent().find('.right')},
			scroll: {
				width: "variable",
				items: 1,
				easing: "easeInOutCirc",
			//	fx: "fade",
				pauseOnHover: true,
				onBefore: onBeforeScroll
			},
			auto: {
				play: true,
				items: 1
			}
		},{
		wrapper: {
			classname: "caroufredsel_wrapper_vertical_carousel"
			}
		});
	});
	
	//accordion
	$(".accordion").each(function(){
		var active_tab = !isNaN(jQuery(this).data('active-tab')) && parseInt(jQuery(this).data('active-tab')) >  0 ? parseInt(jQuery(this).data('active-tab'))-1 : false,
		collapsible =  (active_tab===false ? true : false);
		$(this).accordion({
			event: 'change',
			heightStyle: 'content',
			icons: true,
			active: active_tab,
			collapsible: collapsible,
			create: function(event, ui){
				$(window).trigger('resize');
				$(".horizontal_carousel").trigger('configuration', ['debug', false, true]);
			}
		});
		/*if(!$(this).hasClass("accordion-active"))
		{
			$(this).accordion("option", "collapsible", true);
			$(this).accordion("option", "active", false);
		}*/
	});
	$(".accordion.wide").bind("accordionactivate", function(event, ui){
		if(typeof($("#"+$(ui.newHeader).attr("id")).offset())!="undefined")
			$("html, body").animate({scrollTop: $("#"+$(ui.newHeader).attr("id")).offset().top-20}, 400);
	});
	$(".tabs:not('.no_scroll')").bind("tabsbeforeactivate", function(event, ui){
		$("html, body").animate({scrollTop: $("#"+$(ui.newTab).children("a").attr("id")).offset().top-20}, 400);
	});
	$(".tabs").tabs({
		event: 'change',
		show: true,
		create: function(){
			$("html, body").scrollTop(0);
		}
	});
	
	//browser history
	$(".tabs .ui-tabs-nav a").on("click", function(){
		if($(this).attr("href").substr(0,4)!="http")
			$.bbq.pushState($(this).attr("href"));
		else
			window.location.href = $(this).attr("href");
	});
	$(".ui-accordion .ui-accordion-header").on("click", function(){
		$.bbq.pushState("#" + $(this).attr("id").replace("accordion-", ""));
	});
	
	//preloader
	var preloader = function()
	{
		/*imagesLoaded(".blog:not('.small, .horizontal_carousel') .post>a>img, .blog_grid .post>a>img, .post.single .post_image img, .slider .slide img, .pr_preload").on("progress", function(imagesLoadedInstance, image){
			// Code for each image
		});*/
		$(".blog:not('.small, .horizontal_carousel') .post>a>img, .blog_grid .post>a>img, .post.single .post_image img, .slider .slide img, .pr_preload").each(function(){
			if(!$(this).data("loaded"))
			{
				$(this).before("<span class='pr_preloader'></span>");
				//$(this).attr('src',$(this).attr('src'));
				imagesLoaded($(this)).on("progress", function(instance, image){
					$(image.img).data("loaded", true);
					$(image.img).prev(".pr_preloader").remove();
					$(image.img).css("display", "block");
					$(image.img).parent().css("opacity", "0");
					$(image.img).parent().fadeTo("slow", 1, function(){
						$(this).css("opacity", "");
					});
					$(image.img).parent().children(".icon").css("display", "block");
					if($(image.img).parent().parent().parent().hasClass("blog rating"))
						$(".blog.rating .value_bar_container").each(function(){
							$(this).height($(this).parent().outerHeight()-$(this).parent().find("img").height());
						});
				});
			}
		});
		
	};
	preloader();
	
	$(".scroll_to_comments").on("click", function(event){
		event.preventDefault();
		var offset = $(($(".comments_list_container").children().length ? ".comments_list_container" : ".comment_form_container")).offset();
		$("html, body").animate({scrollTop: offset.top-10}, 400);
	});
	//hashchange
	$(window).bind("hashchange", function(event){
		var hashSplit = $.param.fragment().split("-");
		var hashString = "";
		for(var i=0; i<hashSplit.length-1; i++)
			hashString = hashString + hashSplit[i] + (i+1<hashSplit.length-1 ? "-" : "");
		if(hashSplit[0].substr(0,7)!="filter=")
		{
			$('.ui-accordion .ui-accordion-header#accordion-' + decodeURIComponent($.param.fragment())).trigger("change");
			$(".tabs_box_navigation a[href='#" + decodeURIComponent($.param.fragment()) + "']").trigger("click");
			$('.ui-accordion .ui-accordion-header#accordion-' + decodeURIComponent(hashString)).trigger("change");
		}
		$('.tabs .ui-tabs-nav [href="#' + decodeURIComponent(hashString) + '"]').trigger("change");
		$('.tabs .ui-tabs-nav [href="#' + decodeURIComponent($.param.fragment()) + '"]').trigger("change");
		if(hashSplit[0].substr(0,7)!="filter=")
			$('.tabs .ui-accordion .ui-accordion-header#accordion-' + decodeURIComponent($.param.fragment())).trigger("change");
		$(".latest_news_scrolling_list, .slider_posts_list, .vertical_carousel, .horizontal_carousel").trigger('configuration', ['debug', false, true]);
		$(".blog.rating .value_bar_container").each(function(){
			$(this).height($(this).parent().outerHeight()-$(this).parent().find("img").height());
		});
		$(document).scroll();
		
		if(hashSplit[0].substr(0,7)=="comment")
		{
			if($(location.hash).length)
			{
				var offset = $(location.hash).offset();
				$("html, body").animate({scrollTop: offset.top-10}, 400);
			}
		}
		
		if(hashSplit[0]=="comments")
		{
			$(".single .scroll_to_comments").trigger("click");
		}
		if(hashSplit[0].substr(0,4)=="page")
		{
			if(parseInt($("#comment_form [name='prevent_scroll']").val())==1)
			{
				$("#comment_form [name='prevent_scroll']").val(0);
				$("#comment_form [name='paged']").val(parseInt(location.hash.substr(6)));
			}
			else
			{
				$.ajax({
					url: config.ajaxurl,
					data: "action=theme_get_comments&post_id=" + $("#comment_form [name='post_id']").val() + "&post_type=" + $("#comment_form [name='post_type']").val() + "&paged="+parseInt(location.hash.substr(6)),
					type: "get",
					dataType: "json",
					success: function(json){
						if(typeof(json.html)!="undefined")
						{
							$(".comments_list_container").html(json.html);
							$("abbr.timeago").timeago();
						}
						var hashSplit = location.hash.split("/");
						var offset = null;
						if(hashSplit.length==2 && hashSplit[1]!="")
							offset = $("#" + hashSplit[1]).offset();
						else
							offset = $(".comments_list_container").offset();
						if(offset!=null)
							$("html, body").animate({scrollTop: offset.top-10}, 400);
						$("#comment_form [name='paged']").val(parseInt(location.hash.substr(6)));
					}
				});
				return;
			}
		}
	}).trigger("hashchange");
	
	//$(".gallery_popup").css("display", "none");
	$("a[data-rel]").on("click", function(event){
		event.preventDefault();
		var currentSlideIndex = parseInt($(this).parent().attr("id").split("_")[3]);
		var panelId = "#" + $(this).attr("data-rel") + "-popup";
		if(!$(panelId).hasClass("disabled"))
		{
			$("body").append("<div class='gallery_overlay'></div>");
			$(".gallery_overlay").css({"width":$(window).width()+"px", "height":$(document).height()+"px", "opacity":"1"});
			//var top = ($(window).height()-$(panelId).height())/2+$(window).scrollTop();
			var top = $(window).scrollTop();
			if(top<0)
				top = 0;
			top = 0;
			$(panelId).css("top", top + "px");
			//$(panelId).css("left", ($(window).width()-$(panelId).width())/2+$(window).scrollLeft() + "px");
			$(panelId).appendTo("body").css("display", "block");
			var carouselControl = $(panelId + " .horizontal_carousel_container.thin .horizontal_carousel");
			var carouselControlIndex = parseInt(carouselControl.children(":first").attr("id").split("_")[2]);
			if(carouselControl.children().length<7)
				$(panelId + " .horizontal_carousel_container.thin").css("width", "1050px");
				
			var carousel = $(panelId + " .horizontal_carousel_container.big .horizontal_carousel");
			var carouselIndex = parseInt(carousel.children(":first").attr("id").split("_")[2]);
			if(!carousel.find(".navigation_container").length)
			{
				carousel.children().each(function(index){
					$(this).find(".vc_col-sm-4").prepend("<div class='navigation_container clearfix'><ul id='slider_navigation_" + index + "' class='slider_navigation'><li class='slider_control'><a title='prev' href='#' class='left_" + index + "'></a></li><li class='slider_control'><a title='next' href='#' class='right_" + index + "'></a></li></ul><div class='slider_info'>" + (index+1) + " / " + carousel.children().length + "</div></div>");
					$(panelId + " .left_" + index).on("click", function(event){
						event.preventDefault();
						carousel.trigger("isScrolling", function(isScrolling){
							if(!isScrolling)
							{
								controlBySlideLeft.call(carousel.parent(), carouselIndex);
								carousel.trigger("prevPage");
								
								/*var controlFor = $(".control-for-" + carousel.attr("id").replace("control-by-", ""));
								var currentIndex = controlFor.children().index(controlFor.children(".current"));
								if(currentIndex==0)
								{
									controlFor.trigger("prevPage");
									controlFor.children(".current").removeClass("current").prev().addClass("current");
								}
								else if(currentIndex>controlFor.triggerHandler("currentVisible").length+1)
								{	
									var slideToIndex = parseInt(carousel.children(":first").attr("id").replace("horizontal_slide_" + carouselIndex + "_", ""));
									controlFor.trigger("slideTo", slideToIndex);
									controlFor.children(".current").removeClass("current");
									controlFor.children(":first").addClass("current");
								}
								else
									controlFor.children(".current").removeClass("current").prev().addClass("current");*/
							}
						});
					});
					$(panelId + " .right_" + index).on("click", function(event){
						event.preventDefault();
						carousel.trigger("isScrolling", function(isScrolling){
							if(!isScrolling)
							{
								controlBySlideRight.call(carousel.parent(), carouselIndex);
								carousel.trigger("nextPage");
								/*var controlFor = $(".control-for-" + carousel.attr("id").replace("control-by-", ""));
								var currentIndex = controlFor.children().index(controlFor.children(".current"));
								if(currentIndex==controlFor.triggerHandler("currentVisible").length)
								{
									controlFor.trigger("nextPage");
									controlFor.children(".current").removeClass("current").next().addClass("current");
								}
								else if(currentIndex>controlFor.triggerHandler("currentVisible").length)
								{
									var slideToIndex = parseInt(carousel.children(":first").attr("id").replace("horizontal_slide_" + carouselIndex + "_", ""));
									if(slideToIndex==controlFor.children().length-1)
										slideToIndex = 0;
									else
										slideToIndex++;
									controlFor.trigger("slideTo", slideToIndex);
									controlFor.children(".current").removeClass("current");
									controlFor.children(":first").addClass("current");
								}
								else
									controlFor.children(".current").removeClass("current").next().addClass("current");*/
							}
						});
					});
				});
			}
			carouselControl.children(".current").removeClass("current");
			carousel.trigger('configuration', ['debug', false, true]);
			carouselControl.trigger('configuration', ['debug', false, true]);
			$("#horizontal_slide_" + carouselControlIndex + "_" + currentSlideIndex).addClass("current");
			carousel.trigger("slideTo", [$("#horizontal_slide_" + carouselIndex + "_" + currentSlideIndex), {
				duration    : 10
			}]);
			carouselControl.trigger("slideTo", [$("#horizontal_slide_" + carouselControlIndex + "_" + currentSlideIndex), {
				duration    : 10
			}]);
			$(panelId).css("opacity", "0");
			carousel.trigger('configuration', ['debug', false, true]);
			carouselControl.trigger('configuration', ['debug', false, true]);
			$(panelId).animate({opacity: 1}, 500, function(){if(window.document.documentMode)this.style.removeAttribute("filter");carousel.trigger('configuration', ['debug', false, true]);/*IE bug fix*/});
			$(panelId).css("height", $(window).height()+"px");
			//$("html,body").css("overflow", "hidden").addClass("dont_scroll");
			var scrollPosition = $(window).scrollTop();
			$("body").addClass("lock-position");
			$(".close_popup").one("click", function(event){
				event.preventDefault();
				$(".close_popup").unbind("click");
				//$("html,body").css("overflow", "auto").removeClass("dont_scroll");
				$("body").removeClass("lock-position");
				$(window).scrollTop(scrollPosition);
				$(panelId).css({"top": scrollPosition, "overflow": "hidden"});
				$(panelId).addClass("disabled").animate({opacity:0},500,function(){$(this).css("display", "none").removeClass("disabled");$(panelId).css({"top": 0, "overflow-y": "scroll"});});
				$(".gallery_overlay").animate({opacity:0},500,function(){$(this).remove()});
			});
		}
	});
	$('body.dont_scroll').bind("touchmove", {}, function(event){
	  event.preventDefault();
	});
	
	//History
	History.Adapter.bind(window,'statechange',function(){
		var state = History.getState();
		var stateSplit = state.url.replace(new RegExp(config.home_url, 'g'), "").split("/");
		stateSplit = $.grep(stateSplit,function(n){
			return(n);
		});
		if(typeof(stateSplit)!="undefined")
			var stateSplitLast = stateSplit[stateSplit.length-1];
		var data = state.data;
		
		if(data.pr_option=="theme_blog_pagination" && data.action.length)
		{
			data.atts = $("#pagination" + data.container_id.replace(data.action , '')).next().val();
			$("#" + data.container_id).next().children(".pr_preloader").css("display", "block");
		}
		
		$.ajax({
				url: config.ajaxurl,
				type: 'post',
				dataType: 'html',
				data: data,
				success: function(html){
					//prep vars
					html = $.trim(html);
					var indexPageNumberStart = html.indexOf("page_number_start")+17;
					var indexPageNumberEnd = html.indexOf("page_number_end")-indexPageNumberStart;
					var pageNumber = html.substr(indexPageNumberStart, indexPageNumberEnd);					
					var indexBlogPostsStart = html.indexOf("blog_posts_start")+16;
					var indexBlogPostsEnd = html.indexOf("blog_posts_end")-indexBlogPostsStart;
					var blogPostsHTML = html.substr(indexBlogPostsStart, indexBlogPostsEnd);
					var indexBlogPaginationStart = html.indexOf("blog_pagination_start")+21;
					var indexBlogPaginationEnd = html.indexOf("blog_pagination_end")-indexBlogPaginationStart;
					var blogPaginationHTML = html.substr(indexBlogPaginationStart, indexBlogPaginationEnd);
					
					//modify document
					if(config.page_number<2)
						document.title = document.title + " | " + pageNumber;
					else
					{
						var temp = document.title.split("|");
						temp.pop();
						if(pageNumber!=="")
							temp.push(pageNumber);
						document.title = temp.join(" | ");
					}
					config.page_number = data.paged;
					
					$("#" + data.container_id)[0].innerHTML = blogPostsHTML;
					$("#" + data.container_id).next()[0].outerHTML = blogPaginationHTML;
					$(".pagination_container.ajax." + data.action + " a").on("click", {action: data.action, pr_option: 'theme_blog_pagination'}, pushState);
					$(window).trigger('resize');
					preloader();
					$("html, body").animate({scrollTop: $("#" + data.container_id).offset().top}, 400);
				}
		});
	});
	
	//ajax pagination
	$(".pagination_container.ajax.theme_blog_1_column_pagination a").on("click", {action: 'theme_blog_1_column_pagination', pr_option: 'theme_blog_pagination'}, pushState);
	$(".pagination_container.ajax.theme_blog_2_columns_pagination a").on("click", {action: 'theme_blog_2_columns_pagination', pr_option: 'theme_blog_pagination'}, pushState);
	$(".pagination_container.ajax.theme_blog_3_columns_pagination a").on("click", {action: 'theme_blog_3_columns_pagination', pr_option: 'theme_blog_pagination'}, pushState);
	$(".pagination_container.ajax.theme_blog_big_pagination a").on("click", {action: 'theme_blog_big_pagination', pr_option: 'theme_blog_pagination'}, pushState);
	$(".pagination_container.ajax.theme_blog_medium_pagination a").on("click", {action: 'theme_blog_medium_pagination', pr_option: 'theme_blog_pagination'}, pushState);
	$(".pagination_container.ajax.theme_blog_small_pagination a").on("click", {action: 'theme_blog_small_pagination', pr_option: 'theme_blog_pagination'}, pushState);
	
	//timeago
	$("abbr.timeago").timeago();
	
	if($(".theme_page .vc_row:not('.full_width')").width()>462)
	{
		$(".mobile_menu_container").removeClass("mobile_menu_container").addClass("menu_container");
	}
	else
	{
		$(".menu_container").removeClass("menu_container").addClass("mobile_menu_container");
		if($(".mobile_menu_container ul.ubermenu-nav").hasClass("sf-menu"))
			$(".mobile_menu_container ul.ubermenu-nav").removeClass("sf-menu").addClass("had-sf-menu");
	}
	//window resize
	function windowResize()
	{
		if($(".theme_page .vc_row:not('.full_width')").width()>462)
		{
			$(".mobile_menu_container").removeClass("mobile_menu_container").addClass("menu_container");
			if($(".menu_container ul.ubermenu-nav").hasClass("had-sf-menu"))
				$(".menu_container ul.ubermenu-nav").removeClass("had-sf-menu").addClass("sf-menu");
		}
		else
		{
			$(".menu_container").removeClass("menu_container").addClass("mobile_menu_container");
			if($(".mobile_menu_container ul.ubermenu-nav").hasClass("sf-menu"))
				$(".mobile_menu_container ul.ubermenu-nav").removeClass("sf-menu").addClass("had-sf-menu");
		}
		$(".slider, .small_slider, .latest_news_scrolling_list, .slider_posts_list, .vertical_carousel, .horizontal_carousel").trigger('configuration', ['debug', false, true]);
		
		$(".blog.rating .value_bar_container").each(function(){
			$(this).height($(this).parent().outerHeight()-$(this).parent().find("img").height());
		});
		$(".authors_list.rating .value_bar_container").each(function(){
			$(this).height($(this).parent().outerHeight());
		});
		$(".review_summary .value_bar_container").each(function(){
			$(this).height($(this).parent().outerHeight());
		});
		if($(".slider").length)
		{
			$(".slider").each(function(){
				$(this).sliderControl("destroy");
				var id = "slider";
				var elementClasses = $(this).attr('class').split(' ');
				for(var i=0; i<elementClasses.length; i++)
				{
					if(elementClasses[i].indexOf('id-')!=-1)
						id = elementClasses[i].replace('id-', '');
				}
				$(this).sliderControl({
					appendTo: $(".slider_content_box"),
					listContainer: $("#" + id + ".slider_posts_list_container"),
					listItems: ($(".theme_page .vc_row:not('.full_width')").width()>462 ? 4 : 2)
				});
			});
		}
		if($(".small_slider").length)
		{
			$(".small_slider").each(function(){
				$(this).sliderControl("destroy");
				var id = "small_slider";
				var elementClasses = $(this).attr('class').split(' ');
				for(var i=0; i<elementClasses.length; i++)
				{
					if(elementClasses[i].indexOf('id-')!=-1)
						id = elementClasses[i].replace('id-', '');
				}
				$(this).sliderControl({
					type: "small",
					appendTo: $(".slider_content_box"),
					listContainer: $("#" + id + ".slider_posts_list_container.small"),
					listItems: ($(".theme_page .vc_row:not('.full_width')").width()>462 ? 3 : 2)
					
				});
			});
		}
		if($(".post.single .author_box").length && $(".theme_page .vc_row:not('.full_width')").width()>462)
		{
			var topOfWindow = $(window).scrollTop();
			if($(".post.single.small_image .author_box").length)
			{
				var elementPos = $(".post.single .post_content").offset().top+$(".post.single .post_image_box").outerHeight()+30;
				if(elementPos-20<topOfWindow && $(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()>topOfWindow)
					$(".post.single .author_box").css({"position": "fixed", "top": "20px", "bottom": "auto"});
				else if($(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()<topOfWindow)
					$(".post.single .author_box").css({"position": "absolute", "bottom": "0", "top": "auto"});
				else
					$(".post.single .author_box").css({"position": "absolute", "top": ($(".post.single .post_image_box").outerHeight()+30) + "px", "bottom": "auto"});
			}
			else
			{
				if($(".post.single .post_content").offset().top-20<topOfWindow && $(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()>topOfWindow)
					$(".post.single .author_box").css({"position": "fixed", "top": "20px", "bottom": "auto"});
				else if($(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()<topOfWindow)
					$(".post.single .author_box").css({"position": "absolute", "bottom": "0", "top": "auto"});
				else
					$(".post.single .author_box").css({"position": "absolute", "top": "0", "bottom": "auto"});
			}
		}
		if($(".pr_smart_column").length && $(".theme_page .vc_row:not('.full_width')").width()>462)
		{
			var topOfWindow = $(window).scrollTop();
			$(".pr_smart_column").each(function(){
				var row = $(this).parent();
				var wrapper = $(this).children().first();
				var childrenHeight = 0;
				wrapper.children().each(function(){
					childrenHeight += $(this).outerHeight(true);
				});
				if(childrenHeight<$(window).height() && row.offset().top-20<topOfWindow && row.offset().top-20+row.outerHeight()-childrenHeight>topOfWindow)
				{
					wrapper.css({"position": "fixed", "bottom": "auto", "top": "20px", "width": $(this).width() + "px"});
					$(this).css({"height": childrenHeight+"px"});
				}
				else if(childrenHeight<$(window).height() && row.offset().top-20+row.outerHeight()-childrenHeight<=topOfWindow && (row.outerHeight()-childrenHeight>0))
					wrapper.css({"position": "absolute", "bottom": "0", "top": (row.outerHeight()-childrenHeight) + "px", "width": "auto"});
				else if(childrenHeight>=$(window).height() && row.offset().top+20+childrenHeight<topOfWindow+$(window).height() && row.offset().top+20+row.outerHeight()>topOfWindow+$(window).height())
				{	
					wrapper.css({"position": "fixed", "bottom": "20px", "top": "auto", "width": $(this).width() + "px"});
					$(this).css({"height": childrenHeight+"px"});
				}
				else if(childrenHeight>=$(window).height() && row.offset().top+20+row.outerHeight()<=topOfWindow+$(window).height() && (row.outerHeight()-childrenHeight>0))
					wrapper.css({"position": "absolute", "bottom": "0", "top": (row.outerHeight()-childrenHeight) + "px", "width": "auto"});
				else
					wrapper.css({"position": "static", "bottom": "auto", "top": "auto", "width": "auto"});
			});
		}
		if($(".gallery_overlay").length)
		{
			$(".gallery_overlay").css({"width":$(window).width()+"px", "height":$(document).height()+"px"});
			$(".gallery_popup").css("height", $(window).height()+"px");
		}
		//$(".slider_posts_list").trigger('configuration', ['items', {visible: 2}, true]);	
	}
	$(window).resize(windowResize);
	window.addEventListener('orientationchange', windowResize);	
	
	//scroll top
	$("a[href='#top']").on("click", function() {
		if(navigator.userAgent.match(/(iPod|iPhone|iPad|Android)/))     
			$("body").animate({scrollTop: 0}, "slow");
		else
			$("html, body").animate({scrollTop: 0}, "slow");
		return false;
	});
	
	//hint
	$(".comment_form input[type='text'], .contact_form input[type='text'], .comment_form textarea, .contact_form textarea, .search input[type='text'], .search_form input[type='text'], #review_form textarea").hint();
	
	//cancel comment button
	$("#cancel_comment").on("click", function(event){
		event.preventDefault();
		$(this).css('display', 'none');
	});
	
	//fancybox
	$(".prettyPhoto").prettyPhoto({
		show_title: false,
		slideshow: 3000,
		overlay_gallery: true,
		social_tools: ''
	});
	
	//comment form, contact form
	if($(".contact_form").length)
		$(".contact_form")[0].reset();
	if($(".comment_form").length)
		$(".comment_form")[0].reset();
	$(".comment_form, .contact_form").on("submit", function(event){
		event.preventDefault();
		var data = $(this).serializeArray();
		var id = $(this).attr("id");
		$("#"+id+" [type='checkbox']:not(:checked)").each(function(){
			data.push({name: $(this).attr("name"), value: 0});
		});
		if(parseInt($("#"+id+" [name='name']").data("required"), 10))
			data.push({name: 'name_required', value: 1});
		if(parseInt($("#"+id+" [name='email']").data("required"), 10))
			data.push({name: 'email_required', value: 1});
		if(parseInt($("#"+id+" [name='subject']").data("required"), 10))
			data.push({name: 'subject_required', value: 1});
		if(parseInt($("#"+id+" [name='message']").data("required"), 10))
			data.push({name: 'message_required', value: 1});
		data.push({name: 'name_default', value: $("#"+id+" [name='name']").data("default")});
		data.push({name: 'email_default', value: $("#"+id+" [name='email']").data("default")});
		data.push({name: 'subject_default', value: $("#"+id+" [name='subject']").data("default")});
		data.push({name: 'message_default', value: $("#"+id+" [name='message']").data("default")});
		$("#"+id+" .block").block({
			message: false,
			overlayCSS: {
				opacity:'0.3',
				"backgroundColor": "#FFF"
			}
		});
		$("#"+id+" [type='submit']").prop("disabled", true);
		$.ajax({
			url: config.ajaxurl,
			data: data,
			type: "post",
			dataType: "json",
			success: function(json){
				$("#"+id+" [name='submit'], #"+id+" [name='name'], #"+id+" [name='email'], #"+id+" [name='subject'], #"+id+" [name='message'], #"+id+" .g-recaptcha, #"+id+"terms").qtip('destroy');
				if(typeof(json.isOk)!="undefined" && json.isOk)
				{
					if(typeof(json.submit_message)!="undefined" && json.submit_message!="")
					{
						$("#"+id+" [name='submit']").qtip(
						{
							style: {
								classes: 'ui-tooltip-success'
							},
							content: { 
								text: json.submit_message 
							},
							hide: false,
							position: { 
								my: "right center",
								at: "left center" 
							}
						}).qtip('show');
						//close tooltip after 5 sec
						/*setTimeout(function(){
							$("#"+id+" [name='submit']").qtip("api").hide();
						}, 5000);*/
						if(id=="comment_form" && typeof(json.html)!="undefined")
						{
							$(".comments_list_container").html(json.html);
							$("abbr.timeago").timeago();
							$("#comment_form [name='comment_parent_id']").val(0);
							if(typeof(json.comment_id)!="undefined")
							{
								var offset = $("#comment-" + json.comment_id).offset();
								if(typeof(offset)!="undefined")
									$("html, body").animate({scrollTop: offset.top-10}, 400);
								if(typeof(json.change_url)!="undefined" && $.param.fragment()!=json.change_url.replace("#", ""))
									$("#comment_form [name='prevent_scroll']").val(1);
							}
							if(typeof(json.change_url)!="undefined" && $.param.fragment()!=json.change_url.replace("#", ""))
								$.bbq.pushState(json.change_url);
								//window.location.href = json.change_url;
						}
						$("#"+id)[0].reset();
						if(typeof(grecaptcha)!="undefined")
							grecaptcha.reset();
						$("#cancel_comment").css("display", "none");
						$("#"+id+" input[type='text'], #"+id+" textarea").trigger("focus").trigger("blur");
					}
				}
				else
				{
					if(typeof(json.submit_message)!="undefined" && json.submit_message!="")
					{
						$("#"+id+" [name='submit']").qtip(
						{
							style: {
								classes: 'ui-tooltip-error'
							},
							content: { 
								text: json.submit_message 
							},
							position: { 
								my: "right center",
								at: "left center" 
							}
						}).qtip('show');
						if(typeof(grecaptcha)!="undefined" && grecaptcha.getResponse()!="")
							grecaptcha.reset();
					}
					if(typeof(json.error_name)!="undefined" && json.error_name!="")
					{
						$("#"+id+" [name='name']").qtip(
						{
							style: {
								classes: 'ui-tooltip-error'
							},
							content: { 
								text: json.error_name 
							},
							position: { 
								my: "bottom center",
								at: "top center" 
							}
						}).qtip('show');
					}
					if(typeof(json.error_email)!="undefined" && json.error_email!="")
					{
						$("#"+id+" [name='email']").qtip(
						{
							style: {
								classes: 'ui-tooltip-error'
							},
							content: { 
								text: json.error_email 
							},
							position: { 
								my: "bottom center",
								at: "top center" 
							}
						}).qtip('show');
					}
					if(typeof(json.error_subject)!="undefined" && json.error_subject!="")
					{
						$("#"+id+" [name='subject']").qtip(
						{
							style: {
								classes: 'ui-tooltip-error'
							},
							content: { 
								text: json.error_subject 
							},
							position: { 
								my: "bottom center",
								at: "top center" 
							}
						}).qtip('show');
					}
					if(typeof(json.error_message)!="undefined" && json.error_message!="")
					{
						$("#"+id+" [name='message']").qtip(
						{
							style: {
								classes: 'ui-tooltip-error'
							},
							content: { 
								text: json.error_message 
							},
							position: { 
								my: "bottom center",
								at: "top center" 
							}
						}).qtip('show');
					}
					if(typeof(json.error_captcha)!="undefined" && json.error_captcha!="")
					{
						$("#"+id+" .g-recaptcha").qtip(
						{
							style: {
								classes: 'ui-tooltip-error'
							},
							content: { 
								text: json.error_captcha 
							},
							position: { 
								my: "bottom left",
								at: "top left" 
							}
						}).qtip('show');
					}
					if(typeof(json.error_terms)!="undefined" && json.error_terms!="")
					{
						$("#"+id+"terms").qtip(
						{
							style: {
								classes: 'ui-tooltip-error'
							},
							content: { 
								text: json.error_terms 
							},
							position: { 
								my: (config.is_rtl ? "bottom right" : "bottom left"),
								at: (config.is_rtl ? "top right" : "top left")
							}
						}).qtip('show');
					}
				}
				$("#"+id+" .block").unblock();
				$("#"+id+" [type='submit']").removeProp("disabled");
			}
		});
	});
	//set author box position in small image post layout
	$(".post.single.small_image .author_box").css({"position": "absolute", "top": ($(".post.single .post_image_box").outerHeight()+30) + "px", "bottom": "auto"});
	if($(".menu_container").hasClass("sticky"))
		menu_position = $(".menu_container").offset().top;
	function animateElements()
	{
		$('.animated_element, .tens, .sticky, .pr_smart_column').each(function(){
			var elementPos = $(this).offset().top;
			var topOfWindow = $(window).scrollTop();
			if($(this).hasClass("author_box"))
			{
				if($(this).parent().parent().parent().hasClass("small_image"))
				{
					var elementPos = $(".post.single .post_content").offset().top+$(".post.single .post_image_box").outerHeight()+30;
					if(elementPos-20<topOfWindow && $(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()>topOfWindow)
						$(".post.single .author_box").css({"position": "fixed", "top": "20px", "bottom": "auto"});
					else if($(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()<topOfWindow)
						$(".post.single .author_box").css({"position": "absolute", "bottom": "0", "top": "auto"});
					else
						$(".post.single .author_box").css({"position": "absolute", "top": ($(".post.single .post_image_box").outerHeight()+30) + "px", "bottom": "auto"});
				}
				else
				{
					if($(".post.single .post_content").offset().top-20<topOfWindow && $(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()>topOfWindow)
						$(".post.single .author_box").css({"position": "fixed", "top": "20px", "bottom": "auto"});
					else if($(".post.single .post_content").offset().top-20+$(".post.single .post_content").outerHeight()-$(".post.single .author_box").outerHeight()<topOfWindow)
						$(".post.single .author_box").css({"position": "absolute", "bottom": "0", "top": "auto"});
					else
						$(".post.single .author_box").css({"position": "absolute", "top": "0", "bottom": "auto"});
				}
			}
			else if($(this).hasClass("pr_smart_column"))
			{
				var row = $(this).parent();
				var wrapper = $(this).children().first();
				var childrenHeight = 0;
				wrapper.children().each(function(){
					childrenHeight += $(this).outerHeight(true);
				});
				if(childrenHeight<$(window).height() && row.offset().top-20<topOfWindow && row.offset().top-20+row.outerHeight()-childrenHeight>topOfWindow)
				{
					wrapper.css({"position": "fixed", "bottom": "auto", "top": "20px", "width": $(this).width() + "px"});
					$(this).css({"height": childrenHeight+"px"});
				}
				else if(childrenHeight<$(window).height() && row.offset().top-20+row.outerHeight()-childrenHeight<=topOfWindow && (row.outerHeight()-childrenHeight>0))
					wrapper.css({"position": "absolute", "bottom": "0", "top": (row.outerHeight()-childrenHeight) + "px", "width": "auto"});
				else if(childrenHeight>=$(window).height() && row.offset().top+20+childrenHeight<topOfWindow+$(window).height() && row.offset().top+20+row.outerHeight()>topOfWindow+$(window).height())
				{	
					wrapper.css({"position": "fixed", "bottom": "20px", "top": "auto", "width": $(this).width() + "px"});
					$(this).css({"height": childrenHeight+"px"});
				}
				else if(childrenHeight>=$(window).height() && row.offset().top+20+row.outerHeight()<=topOfWindow+$(window).height() && (row.outerHeight()-childrenHeight>0))
					wrapper.css({"position": "absolute", "bottom": "0", "top": (row.outerHeight()-childrenHeight) + "px", "width": "auto"});
				else
					wrapper.css({"position": "static", "bottom": "auto", "top": "auto", "width": "auto"});
			}
			else if($(this).hasClass("sticky"))
			{
				if(menu_position!=null)
				{
					if(menu_position<topOfWindow)
						$(this).addClass("move");
					else
						$(this).removeClass("move");
				}
			}
			else if(elementPos<topOfWindow+$(window).height()-20) 
			{
				if($(this).hasClass("number") && !$(this).hasClass("progress") && $(this).is(":visible"))
				{
					var self = $(this);
					$(".blog.rating .value_bar_container").each(function(){
						$(this).height($(this).parent().outerHeight()-$(this).parent().find("img").height());
					});
					$(".authors_list.rating .value_bar_container").each(function(){
						$(this).height($(this).parent().outerHeight());
					});
					self.addClass("progress");
					if(typeof(self.data("value"))!="undefined")
					{
						var value = parseFloat(self.data("value").toString().replace(" ",""));
						self.text(0);
						self.text(value);
					}
					if(self.hasClass("tens"))
					{
						var i = 0;
						var iterator = 0.08;
						var numberInterval = setInterval(function(){
							self.text(i.toFixed(1));
							i+=iterator;
							if(i>value)
							{
								self.text(value.toFixed(1));
								clearInterval(numberInterval);
							}
						}, 10);
					}
					$(".review_summary .value_bar_container").each(function(){
						$(this).height($(this).parent().outerHeight());
					});
					/*var i = 0;
					var iterator = Math.pow(10, value.toString().length-2);
					if(iterator<1)
						iterator = 1;
					if(self.hasClass("tens"))
						iterator = 0.08;
					var numberInterval = setInterval(function(){
						self.text((self.hasClass("tens") ? i.toFixed(1) : i));
						i+=iterator;
						if(i>value)
						{
							self.text((self.hasClass("tens") ? value.toFixed(1) : value));
							clearInterval(numberInterval);
						}
					}, 1);*/
				}
				else if(!$(this).hasClass("progress"))
				{
					var elementClasses = $(this).attr('class').split(' ');
					var animation = "fadeIn";
					var duration = 600;
					var delay = 0;
					for(var i=0; i<elementClasses.length; i++)
					{
						if(elementClasses[i].indexOf('animation-')!=-1)
							animation = elementClasses[i].replace('animation-', '');
						if(elementClasses[i].indexOf('duration-')!=-1)
							duration = elementClasses[i].replace('duration-', '');
						if(elementClasses[i].indexOf('delay-')!=-1)
							delay = elementClasses[i].replace('delay-', '');
					}
					$(this).addClass(animation);
					$(this).css({"animation-duration": duration + "ms"});
					$(this).css({"animation-delay": delay + "ms"});
					$(this).css({"transition-delay": delay + "ms"});
				}
			}
		});
	}
	setTimeout(animateElements, 1);
	$(window).scroll(animateElements);
	//high contrast switch
	$(".high_contrast_switch_icon").on("click", function(event){
		event.preventDefault();
		setCookie("pr_header_top_bar_container", "");
		setCookie("pr_header_container", "");
		setCookie("pr_social_icons", "");
		setCookie("pr_menu_container", "");
		if((typeof(getCookie("pr_color_skin"))!="undefined" && getCookie("pr_color_skin")!="high_contrast") || (typeof(getCookie("pr_color_skin"))=="undefined" && config.color_scheme!="high_contrast"))
		{
			setCookie("pr_previous_skin", (typeof(getCookie("pr_color_skin"))!="undefined" ? getCookie("pr_color_skin") : config.color_scheme));
			setCookie("pr_color_skin", "high_contrast");
			setCookie("pr_header_top_bar_container", "style_5 border");
			setCookie("pr_social_icons", "dark");
			setCookie("pr_header_container", "style_3" + ($(".header_container").hasClass("small") ? " small" : ""));
			//setCookie("pr_main_color", "");
		}
		else
		{
			if(getCookie('pr_previous_skin')=="dark")
			{
				//setCookie("pr_main_color", "8CC152");
				setCookie("pr_header_top_bar_container", "style_4");
				setCookie("pr_header_container", "style_2" + ($(".header_container").hasClass("small") ? " small" : ""));
				setCookie("pr_color_skin", "dark");
			}
			else
			{
				//setCookie("pr_main_color", "ED1C24");
				setCookie("pr_color_skin", "light");
			}
			setCookie("pr_social_icons", "");
		}
		location.reload();
	});
	//font selector
	var font_size = 0, size_to_set = 0;
	$(".font_selector a").on("click", function(event){
		event.preventDefault();
		if($(this).hasClass("increase"))
			font_size = 2;
		else
			font_size = -2;
		$("p").each(function(){
			size_to_set = (parseInt($(this).css("font-size"))+font_size);
			if(size_to_set>8 && size_to_set<40)
				$(this).css("font-size", size_to_set + "px");
		});
	});
	//woocommerce
	$(".woocommerce .quantity .plus").on("click", function(){
		var input = $(this).prev();
		input.val(parseInt(input.val())+1);
		$("input[name='update_cart']").removeAttr("disabled");
	});
	$(".woocommerce .quantity .minus").on("click", function(){
		var input = $(this).next();
		input.val((parseInt(input.val())-1>0 ? parseInt(input.val())-1 : 0));
		$("input[name='update_cart']").removeAttr("disabled");
	});
	$(document.body).on("updated_cart_totals", function(){
		$(".woocommerce .quantity .plus").off("click");
		$(".woocommerce .quantity .plus").on("click", function(){
			var input = $(this).prev();
			input.val(parseInt(input.val())+1);
			$("input[name='update_cart']").removeAttr("disabled");
		});
		$(".woocommerce .quantity .minus").off("click");
		$(".woocommerce .quantity .minus").on("click", function(){
			var input = $(this).next();
			input.val((parseInt(input.val())-1>0 ? parseInt(input.val())-1 : 0));
			$("input[name='update_cart']").removeAttr("disabled");
		});
		var sum = 0;
		$(".shop_table.cart .input-text.qty.text").each(function(){
			sum += parseInt($(this).val());
		});
		if(sum>0)
			$(".cart_items_number").html(sum).css("display", "block");
	});
	$(document.body).on("added_to_cart", function(event, data){
		var sum = 0;
		$(data["div.widget_shopping_cart_content"]).find(".quantity").each(function(){
			sum += parseInt($(this).html());
		});
		if(sum>0)
			$(".cart_items_number").html(sum).css("display", "block");
	});
});