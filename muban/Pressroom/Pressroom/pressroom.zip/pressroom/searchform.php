<form class="search_form" action="<?php echo esc_url(get_home_url()); ?>">
	<input name="s" class="search_input" type="text" value="<?php esc_attr_e('Search...', 'pressroom'); ?>" placeholder="<?php esc_attr_e('Search...', 'pressroom'); ?>">
	<input type="submit" value="" class="search_submit">
</form>